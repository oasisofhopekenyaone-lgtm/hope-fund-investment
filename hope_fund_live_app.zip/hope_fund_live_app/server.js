require('dotenv').config();
const express = require('express');
const Database = require('better-sqlite3');
const path = require('path');
const app = express();
app.use(express.json({limit:'100kb'}));
app.use(express.urlencoded({extended:false}));
const dbPath = process.env.DATABASE_PATH || path.join(__dirname,'hopefund.sqlite');
const db = new Database(dbPath);
db.exec(`CREATE TABLE IF NOT EXISTS deposits (
 id INTEGER PRIMARY KEY AUTOINCREMENT, receipt TEXT UNIQUE, amount REAL NOT NULL,
 account_ref TEXT NOT NULL, phone TEXT, status TEXT NOT NULL DEFAULT 'PENDING',
 source TEXT NOT NULL DEFAULT 'member-submission', raw_json TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 confirmed_at TEXT
)`);
app.use(express.static(path.join(__dirname,'public')));
const adminPass = process.env.ADMIN_PASSWORD;
if (!adminPass || adminPass.length < 16) { console.error('ADMIN_PASSWORD must be set to at least 16 characters'); process.exit(1); }
function admin(req,res,next){const p=req.headers['x-admin-password']||req.query.password;if(p!==adminPass)return res.status(401).json({error:'Unauthorized'});next();}
app.post('/api/deposit/submit',(req,res)=>{
 const amount=Number(req.body.amount), receipt=String(req.body.receipt||'').trim().toUpperCase(), ref=String(req.body.account_ref||process.env.DEFAULT_ACCOUNT_REF||'47715').trim(), phone=String(req.body.phone||'').trim();
 if(!Number.isFinite(amount)||amount<=0||amount>10000000||!receipt||receipt.length<6||receipt.length>20||!ref)return res.status(400).json({error:'Enter a valid amount, M-Pesa receipt, and account reference.'});
 try{const r=db.prepare('INSERT INTO deposits(receipt,amount,account_ref,phone) VALUES(?,?,?,?)').run(receipt,amount,ref,phone);res.json({ok:true,id:r.lastInsertRowid,message:'Submitted. Deposit remains pending until verified.'});}catch(e){if(String(e).includes('UNIQUE'))return res.status(409).json({error:'This M-Pesa receipt has already been submitted.'});res.status(500).json({error:'Could not save deposit submission.'});}
});
// Daraja C2B v2 Confirmation URL: configure this endpoint in Safaricom after deploying over HTTPS.
app.post('/api/daraja/c2b/confirmation',(req,res)=>{
 const d=req.body||{}; const receipt=String(d.TransID||'').trim().toUpperCase(); const amount=Number(d.TransAmount); const ref=String(d.BillRefNumber||process.env.DEFAULT_ACCOUNT_REF||'').trim();
 if(receipt&&Number.isFinite(amount)&&amount>0){try{db.prepare(`INSERT OR IGNORE INTO deposits(receipt,amount,account_ref,phone,status,source,raw_json,confirmed_at) VALUES(?,?,?,?, 'CONFIRMED','daraja-callback',?,CURRENT_TIMESTAMP)`).run(receipt,amount,ref,String(d.MSISDN||''),JSON.stringify(d));}catch(err){console.error('Callback storage error',err);}}
 res.json({ResultCode:0,ResultDesc:'Accepted'});
});
app.get('/api/admin/deposits',admin,(req,res)=>{res.json(db.prepare('SELECT * FROM deposits ORDER BY id DESC LIMIT 500').all());});
app.get('/admin', (req,res)=>res.sendFile(path.join(__dirname,'public','admin.html')));
app.post('/api/admin/deposits/:id/verify',admin,(req,res)=>{const id=Number(req.params.id);const r=db.prepare("UPDATE deposits SET status='VERIFIED',confirmed_at=CURRENT_TIMESTAMP WHERE id=? AND status='PENDING'").run(id);if(!r.changes)return res.status(404).json({error:'Pending deposit not found.'});res.json({ok:true});});
app.post('/api/admin/deposits/:id/reject',admin,(req,res)=>{const id=Number(req.params.id);const r=db.prepare("UPDATE deposits SET status='REJECTED' WHERE id=? AND status='PENDING'").run(id);if(!r.changes)return res.status(404).json({error:'Pending deposit not found.'});res.json({ok:true});});
app.get('/health',(req,res)=>res.json({ok:true,service:'Hope Fund deposits'}));
const port=process.env.PORT||3000;app.listen(port,()=>console.log(`Hope Fund deposit server running on http://localhost:${port}`));
