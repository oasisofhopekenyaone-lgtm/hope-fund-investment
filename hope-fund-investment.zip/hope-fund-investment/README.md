# Hope Fund Investment Platform

Starter website package for deployment on Render.


## Files
- `server.js`: Express server
- `package.json`: dependencies and start script
- `render.yaml`: Render service configuration
- `public/index.html`: landing page

## Run locally
1. Install Node.js 18+
2. In this folder, run `npm install`
3. Run `npm start`
4. Open `http://localhost:10000`

## Deploy
Push this folder's contents to your GitHub repository, then create a Render Web Service using the repository. Render can detect `render.yaml`.


**Important:** This starter does not yet include live account registration, persistent database storage, verified deposit processing, secure admin access, or real withdrawals. Those must be implemented and tested before handling money or member data.
